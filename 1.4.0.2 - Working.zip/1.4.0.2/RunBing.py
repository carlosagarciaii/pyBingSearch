from selenium import webdriver
#from selenium.webdriver.common.by import By
#from selenium.webdriver.support.ui import WebDriverWait
#from selenium.webdriver.support import expected_conditions as EC
from random import *
import time, logging, os, traceback, sys, pyautogui,openpyxl
from datetime import datetime

#Logging

loggingDir = os.path.dirname(os.path.abspath(__file__)) + "/Logging/"

if (not os.path.exists(loggingDir)):
    os.mkdir(loggingDir)

logging.basicConfig(filename=loggingDir + os.path.basename(__file__) + '_diagnostic.log', format='%(asctime)s %(message)s', level=logging.DEBUG)
vLoggingSegmenter = "Closing Log\n\n________________________________________________________\n________________________________________________________\n\n"

def BrowserKicker(browser):
    if (browser.lower() == "chrome" or browser.lower() == "google"):
        driver = webdriver.Chrome(executable_path='Drivers/chromedriver.exe')
    elif browser.lower() == "edge" :
        driver = webdriver.Edge(executable_path='Drivers/msedgedriver.exe')
    elif (browser.lower() == "ie" or browser.lower() == "explorer" or browser.lower() == "iexplore"):
        driver = webdriver.Ie(executable_path='Drivers/IEDriverServer.exe')
    elif (browser.lower() == "firefox" or browser.lower() == "ff" or browser.lower() == "mozilla"):
        driver = webdriver.Firefox(executable_path='Drivers/geckodriver.exe')
    return driver

#Set Browser
xxBrowser = pyautogui.confirm(text='Select a Browser to Use',title='Browser to Use',buttons=('IE','Edge','FireFox','Chrome','Quit'))

targetXLS = 'bingSearchConf.xlsx'

book = openpyxl.load_workbook(targetXLS)
sheet = book.active
rowCount = sheet.max_row

userInfo = {}

for x in range(2,rowCount + 1):
    userInfo[x-1] = {}
    userInfo[x-1]['User'] = sheet.cell(row=x,column=1).value
    userInfo[x-1]['Pass'] = sheet.cell(row=x,column=2).value
    
    pass

for x in userInfo:
    print('User' + str(x) + '\t' + str(userInfo[x]["User"]) + '\n' +'Pass' + str(x) + '\t' + str(userInfo[x]["Pass"]) + '\n' )

    MasterUser = str(userInfo[x]["User"]).replace(' ','')
    MasterPass = str(userInfo[x]["Pass"]).replace(' ','')

    driver = BrowserKicker(xxBrowser)

    from _BingLogin import *
    BingLogin(driver).Login(MasterUser,MasterPass)

    try:
        from _BingRewards import *
        print('Starting Bing Rewards')
        BingRewards(driver).Start()
        sheet.cell(row=x+1,column=4).value = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
    except Exception as e:
        print('\n-----------------------------\nEXCEPTION\n-----------------------------\n' + str(e))
        sheet.cell(row=x+1,column=4).value = 'FAIL - ' + str(datetime.now().strftime('%Y/%m/%d %H:%M:%S'))


    
    try:
        from _BingSearch import *
        print('Starting Bing Search')
        #BingSearcher(driver).Start()
        from datetime import datetime
        logTime = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
        sheet.cell(row=x+1,column=3).value = logTime
    except Exception as e:
        print('\n-----------------------------\nEXCEPTION\n-----------------------------\n' + str(e))
        try:
            from datetime import datetime
            logTime = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
            sheet.cell(row=x+1,column=3).value = 'FAIL - ' + str(datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
        except:
            print('Failed to write log to sheet')


    book.save(targetXLS)
    
    while 1==1:
        try:
            driver.quit()
            time.sleep(3)
        except:
            break



        




