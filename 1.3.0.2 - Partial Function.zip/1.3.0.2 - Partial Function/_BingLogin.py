from _xlog import *
from _SmartFinder import *


from selenium import webdriver
import time,os,sys,logging,datetime
from random import *
class BingLogin(SF,xlog):
    def __init__(self,driver,username,password):
        self.driver = driver
        self.username = username
        self.password = password
        SF.__init__(self,driver=self.driver)

        
    def Start(self):
        
        print('BingLogin - Step\tNave to login.live.com')
        self.driver.get('https://login.live.com')
        time.sleep(randint(3,9))
        print('Current Title:\t' + self.driver.title)
        print('Current URL:\t' + self.driver.current_url)

        print('\nBingLogin - Step\tFind name("loginfmt")')    
        if (SF.find_element_by_name_validation('loginfmt')):
            self.driver.find_element_by_name('loginfmt').send_keys(username)
            time.sleep(randint(2,5))
        print('\nBingLogin - Step\tFind xpath(//Input[@type="submit"])')    
        if (SF.find_element_by_xpath_validation('//Input[@type="submit"]')):
            self.driver.find_element_by_xpath('//Input[@type="submit"]').click()
            time.sleep(randint(5,10))

        print('\nBingLogin - Step\tFind name(\'passwd\')') 
        if (SF.find_element_by_name_validation('passwd')):
            self.driver.find_element_by_name('passwd').send_keys(password)
            time.sleep(randint(2,5))
        
        print('\nBingLogin - Step\tFind xpath(//Input[@type="submit"])') 
        if (SF.find_element_by_xpath_validation('//Input[@type="submit"]')):
            self.driver.find_element_by_xpath('//Input[@type="submit"]').click()
            time.sleep(randint(5,10))
        
        print('\nBingLogin - Step\tFind xpath(//Input[@value="No"])') 
        if (SF.find_element_by_xpath_validation('//Input[@value="No"]')):
            self.driver.find_element_by_xpath('//Input[@value="No"]').click()
            time.sleep(randint(8,15))
        return True
    


        

print('BingLogin\t-\tSUCCESS')
