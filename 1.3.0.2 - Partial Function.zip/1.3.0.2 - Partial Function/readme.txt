You must download and place the Selenium drivers in the "Drivers" directory. 
The application starts using the RunBing.py