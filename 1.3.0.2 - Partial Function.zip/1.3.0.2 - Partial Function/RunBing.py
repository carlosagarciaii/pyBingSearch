from _xlog import *
xlog()

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from random import *
import time, logging, os, traceback, sys, datetime, pyautogui, configparser
print('\n\n')

#Logging


#Set Config
INIFile = os.path.dirname(os.path.abspath(__file__)) + r'\BingSearch.ini'
config = configparser.ConfigParser()

if (not os.path.exists(INIFile)):
    configFile = open(INIFile,"w+")
    configFile.write(r'')
    configFile.close()
    config.read(INIFile)
    config['BingAuto'] = {'username':'Your_UN','password':'Your_PW'}
    config.write(open(INIFile, 'w'))
    print('Please Edit the Configuration File\n\t' + INIFile)
    logging.debug('\n\nThe configuration was not found. Please open the configuration file and update before starting:\n\t\t' + INIFile + '\n\n')
    sys.exit()
    

config.read(INIFile)
MasterUser = config['BingAuto']['username']
MasterPass = config['BingAuto']['password']



def BrowserKicker(browser):
    if (browser.lower() == "chrome" or browser.lower() == "google"):
        driver = webdriver.Chrome(executable_path='Drivers/chromedriver.exe')
    elif browser.lower() == "edge" :
        driver = webdriver.Edge(executable_path='Drivers/msedgedriver.exe')
    elif (browser.lower() == "ie" or browser.lower() == "explorer" or browser.lower() == "iexplore"):
        driver = webdriver.Ie(executable_path='Drivers/IEDriverServer.exe')
    elif (browser.lower() == "firefox" or browser.lower() == "ff" or browser.lower() == "mozilla"):
        driver = webdriver.Firefox(executable_path='Drivers/geckodriver.exe')
    return driver

#Set Browser
xxBrowser = pyautogui.confirm(text='Select a Browser to Use',title='Browser to Use',buttons=('IE','Edge','FireFox','Chrome','Quit'))
driver = BrowserKicker(xxBrowser)

from _BingLogin import *

BingLogin(driver,MasterUser,MasterPass).Start()

'''
from _BingRewards import *
print('Starting Bing Rewards')
BingRewards.Start(driver).Start()
'''
from _BingSearch import *
print('Starting Bing Search')
BingSearcher(driver).Start()


