from _xlog import *
from _SmartFinder import *

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time,os,sys,logging,datetime
from random import *

class BingRewards(SF,xlog):
    def __init__(self,driver):
        self.driver = driver
        SF.__init__(self,driver=self.driver)
        xlog()

    def Start(self):
        self.driver.switch_to.window(self.driver.window_handles[0])
        
        self.driver.get('http://bing.com/rewards')
        time.sleep(randint(7,12))
        self.driver.switch_to.window(self.driver.window_handles[0])

        print('Finding Daily Links')
        assert RPageLinkCycle('//div[@class="c-card-content"]/card-content/mee-rewards-daily-set-item-content/div/div/a'),'RPageLinkCycle() Failed'

        print('Finding Past Links')

        assert RPageLinkCycle('//mee-rewards-more-activities-card-item/div[@mee-rewardable=""]/div/a[@mee-call-to-action="lightweight"]'),'RPageLinkCycle() Failed'
        return True        
       

    def RPageLinkCycle(xpath):
        links = self.driver.find_elements_by_xpath(xpath)
        
        for link in links:

            HomeTab()
            try:
                print('Scrolling Link into view')
                self.driver.execute_script("arguments[0].scrollIntoView();",link)
                time.sleep(3)
                
                print('Clicking Link')
                if SafeClick(link):

                    time.sleep(5)
                    print('Switching to Link Window/Tab')
                    self.driver.switch_to.window(self.driver.window_handles[1])
                
                    if (SF.find_element_by_xpath_validation('//div[contains(text(),"Bing homepage quiz")]') ):
                        print(r'Running:' + '\t' + r'BingQuiz()')
                        BingQuizABC()
                    
                    elif (SF.find_element_by_xpath_validation('//div[text()="Today\'s Rewards poll"]')):
                        print(r'Running:' + '\t' + r'DailyPoll()')
                        DailyPoll()

                    elif(SF.find_element_by_xpath_validation('//h2[text()="Supersonic quiz"]')  ):
                        print(r'Running:' + '\t' + r'SupersonicQuiz()')
                        SupersonicQuiz()
                    elif(SF.find_element_by_xpath_validation('//h2[text()="Lightspeed quiz"]') ):
                        print(r'Running:\t' + r'Lightspeed Quiz')
                        LightspeedQuiz()
                    elif(SF.find_element_by_xpath_validation('//h2[@class="b_topTitle"][text()="This or That?"]') ):
                        print(r'Running:\t' + r'This or That')
                        ThisOrThat()

                
                time.sleep(randint(4,8))
                HomeTab('all')
                print('\n\n-------------Cycle End-------------\n\n')
                         
            except Exception as e:
                print('\n\nException Thrown\n\n' + str(e) + '\n\n')
                xlogit(e)

        return True



    def DailyPoll():
        self.driver.switch_to.window(self.driver.window_handles[1])
        time.sleep(randint(3,6))
        try:
            rng = randint(0,1)
            SF.find_element_by_xpath_safeClick('//div[@id="btoption' + str(rng) + '"]/div/div[@class="bt_PollRadio"]')
        except Exception as e:
            print('\n\nAn Exception Occurred\n\n' + str(e) + '\n\n')
            xlogit(e)
        time.sleep(randint(3,6))
        HomeTab()
        time.sleep(randint(3,6))

    def BingQuizABC():
        self.driver.switch_to.window(self.driver.window_handles[1])
        time.sleep(randint(3,6))
        try:
            if (not SF.find_element_by_xpath_validation('//a[text()="Check your dashboard for more ways to earn."]')):
                refreshCounter = 5
                while (1==1):
                    refreshCounter -= 1
                    rng=randint(1,3)
                    if (rng==1):
                        if (SF.find_element_by_xpath_safeClick('//span[@class="wk_Circle"][text()="A"]')):
                            refreshCounter = 5
                        time.sleep(randint(3,6))
                    elif(rng==2):
                        if(SF.find_element_by_xpath_safeClick('//span[@class="wk_Circle"][text()="B"]')):
                            refreshCounter = 5
                        time.sleep(randint(3,6))
                    else:
                        if(SF.find_element_by_xpath_safeClick('//span[@class="wk_Circle"][text()="C"]')):
                            refreshCounter = 5
                        time.sleep(randint(3,6))
                    

                    if (SF.find_element_by_xpath_safeClick('//input[@type="submit"][@value="Next question"]')):
                        refreshCounter = 5
                    if (SF.find_element_by_xpath_safeClick('//input[@type="submit"][@value="Get your score"]')):
                        break
                    time.sleep(randint(3,6))
                    if (refreshCounter == 0):
                        self.driver.refresh()

        except Exception as e:
             xlogit(e)

        HomeTab()
        time.sleep(randint(3,6))


    def SupersonicQuiz():
        runQuiz = True
        self.driver.switch_to.window(self.driver.window_handles[1])
        time.sleep(randint(3,6))
        #self.driver.find_element_by_id('rqStartQuiz').click()
        time.sleep(randint(3,6))
        questionNum = int(self.driver.find_element_by_xpath('//span[@class="rqECredits"]').text.replace(r'"',r'').replace(r' ',r''))/10
        questionNum = int(questionNum)
        try:
            while (runQuiz):
                print('Supersonic Cycle:\t' + str(h))
                for i in range(0,8):
                    if (SF.find_element_by_xpath_validation('//*[contains(text(),"you just earned")]')):
                        print('\n\n------------------Quiz Completed------------------\n\n')
                        runQuiz = False
                        break
                    print('Clicking:\trqAnswerOption' + str(i))
                    SF.find_element_by_xpath_safeClick('//div[@id="rqAnswerOption' + str(i) + '"]')
                    time.sleep(randint(2,4))
                    
        except Exception as e:
            print('\n\nAn Exception has occurred\n\n' + str(e) + '\n\n')
            xlogit(e)
                  
        HomeTab()
        time.sleep(randint(3,6))


    def LightspeedQuiz():
        
        self.driver.switch_to.window(self.driver.window_handles[1])
        time.sleep(randint(3,6))
        self.driver.find_element_by_id('rqStartQuiz').click()
        questionNum = int(self.driver.find_element_by_xpath('//span[@class="rqText"]/span[@class="rqPoints"]').text.replace( r'/',r'').replace(r' ',r'')) /10
        questionNum = int(questionNum)
        try:
            for h in range(0,questionNum):
                print('Supersonic Cycle:\t' + str(h))
                for i in range(0,4):
                    print('Clicking:\trqAnswerOption' + str(i))
                    SF.find_element_by_xpath_safeClick('//input[@id="rqAnswerOption' + str(i) + '"]')
                    time.sleep(randint(3,6))
                    if (self.driver.find_element_by_xpath('//span[@id="rqAnsStatus"]').text != r'Oops, try again!'):
                        break
                    time.sleep(randint(4,7))
            HomeTab()
        except Exception as e:
            print('\n\nAn Exception has occurred\n\n' + str(e) + '\n\n')
            xlogit(e)
              
        HomeTab()
        time.sleep(randint(3,6))


     
    def ThisOrThat():
        
        self.driver.switch_to.window(self.driver.window_handles[1])
        time.sleep(randint(3,6))

        try:
            self.driver.find_element_by_xpath('//input[@type="button"][@value="Start playing"]').click()
            for x in range(0,9):
                time.sleep(randint(4,7))
                print('Getting Option 1')
                option1 = self.driver.find_element_by_xpath('//div[@id="rqAnswerOption0"]/div[@class="btOptionText"]').text
                print('Getting Option 2')
                option2 = self.driver.find_element_by_xpath('//div[@id="rqAnswerOption1"]/div[@class="btOptionText"]').text
                print('Getting Question')
                questionText = self.driver.find_element_by_xpath('//div[@class="bt_queText"]').text.replace(r'?',r'')

                questionText = questionText + r' ' + option1 + r' or ' + option2
                
                links = self.driver.find_elements_by_xpath('//a')
                links[0].send_keys(Keys.CONTROL + Keys.RETURN)
                time.sleep(randint(3,7))
                self.driver.switch_to.window(self.driver.window_handles[2])
                self.driver.get('http://bing.com')

                time.sleep(randint(3,7))
                print('Searching for:\t' + questionText)
                self.driver.find_element_by_id("sb_form_q").send_keys(questionText)
                time.sleep(randint(3,5))
                self.driver.find_element_by_id("sb_form_q").send_keys(Keys.RETURN)
                resultLinks = self.driver.find_elements_by_xpath('//a')

                for x in range(0,len(resultLinks)):
                    if option1 in resultLinks[x].text or option1.replace(r',',r' ') in resultLinks[x].text :
                        try:
                            while 1==1:
                                self.driver.switch_to.window(self.driver.window_handles[2])
                                self.driver.close()
                        except:
                            print('Search Tabs Closed')
                        self.driver.switch_to.window(self.driver.window_handles[1])
                        time.sleep(randint(2,5))
                        self.driver.find_element_by_xpath('//div[@id="rqAnswerOption0"]').click()
                        break
                    elif option2 in resultLinks[x].text or option2.replace(r',',r' ') in resultLinks[x].text :
                        try:
                            while 1==1:
                                self.driver.switch_to.window(self.driver.window_handles[2])
                                self.driver.close()
                        except:
                            print('Search Tabs Closed')
                        self.driver.switch_to.window(self.driver.window_handles[1])
                        time.sleep(randint(2,5))
                        self.driver.find_element_by_xpath('//div[@id="rqAnswerOption1"]').click()
                        break

                    try:
                        while 1==1:
                            self.driver.switch_to.window(self.driver.window_handles[2])
                            self.driver.close()
                    except:
                        print('Search Tabs Closed')
                        self.driver.switch_to.window(self.driver.window_handles[1])
                        self.driver.refresh()
                        
                        
                time.sleep(randint(3,6))
            
        except Exception as e:
            print('\n\nAN EXCEPTION WAS THROWN\n\n' + str(e) + '\n\n')
            xlogit(e)
        
        HomeTab()
        time.sleep(randint(3,6))             
        
        



print('BingRewards Load:\tSuccess')











    
