
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

#Smart Finder or SF will be commonly used methods
class SF:
    def __init__(self,driver):
        self.driver = driver
        

    def find_element_by_name_validation(name):
        try:
            self.driver.find_element_by_name(name)
        except Exception as e:
            print('\n\nCould Not Find Name:\t' + name + '\n\n' + str(e) + '\n\n')
            return False
                
        return True

    def find_element_by_xpath_validation(xpath):
        try:
            self.driver.find_element_by_xpath(xpath)
        except Exception as e:
            print('\n\nCould Not Find Xpath:\t' + xpath + '\n\n' + str(e) + '\n\n')
            return False
                    
        return True
    

    def SafeClick(link):
        try:
            link.click()
        except:
            print('Failed to Click Link')



    def find_element_by_xpath_safeClick(xpath):
        try:
            element = self.driver.find_element_by_xpath(xpath)
            self.driver.execute_script("arguments[0].scrollIntoView();",element)
            element.click()
            time.sleep(3)
        except Exception as e:
            print('Failed to find:\t' + xpath)
            return False
        
            print('Found:\t' + xpath)
        return True



    def HomeTab(closeAll = None):

        try:
            if closeAll == None:
                self.driver.switch_to.window(self.driver.window_handles[1])
                self.driver.close()
            else:
                while 1==1:
                    
                    self.driver.switch_to.window(self.driver.window_handles[1])
                    self.driver.close()

        except:
            print('All additional Tabs Should be Closed')

        self.driver.switch_to.window(self.driver.window_handles[0])


      