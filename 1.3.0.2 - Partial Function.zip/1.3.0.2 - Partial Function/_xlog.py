import logging,sys,os, traceback,time,datetime

class xlog:
	def __init__(self,level = 0):

		loggingDir = os.path.dirname(os.path.abspath(__file__)) + r'\logging'

		logFilePath = loggingDir + os.path.basename(__file__) + '_diagnostic.log'
		logFormat = '$(asctime)s : %(levelname)s) : %(name)s \n\t %(message)s \n\n'

		if level == 0:
			logging.basicConfig(filename=logFilePath, format=logFormat, level=logging.DEBUG)
		elif level == 1:
			logging.basicConfig(filename=logFilePath, format=logFormat, level=logging.INFO)
		elif level == 2:
			logging.basicConfig(filename=logFilePath, format=logFormat, level=logging.WARNING)
		elif level == 3:
			logging.basicConfig(filename=logFilePath, format=logFormat, level=logging.ERROR)
		elif level == 4:
			logging.basicConfig(filename=logFilePath, format=logFormat, level=logging.CRITICAL)
		else:
			logging.basicConfig(filename=logFilePath, format=logFormat, level=logging.DEBUG)

	def xlogIt(self,e):
		logging.debug('\n\nEXCEPTION THROWN\n' + e + '\n\n')


print('xlog loaded')

'''

#logging		
		logging.debug
		logging.info
		logging.warning
		logging.error
		logging.critical
		
			
		#ALT
			logger = logging.getLogger(__name__)
			fileHandler = logging.FileHandler('logfilePath.log')
			logger.addHandler(fileHandler)
			
			formatter = logging.Formatter('logFormat')
					IE:	formatter = logging.Formatter('$(asctime)s : %(levelname)s) : %(name)s :%(message)s')
			fileHandler.setFormatter(formatter)
			logger.setLevel(logging.--level--) (IE: logging.info)

'''