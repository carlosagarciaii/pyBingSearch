from _xlog import *

from selenium import webdriver
import time,os,sys,logging,datetime
from random import *
from _BingSearchWordList import *


class BingSearcher(xlog):
    def __init__(self,driver):
        self.driver = driver
        SF.__init__(self,driver=self.driver)
        xlog()

    def Start(self,loops =  50):
        print('Navigating to Bing.com')
        self.driver.get('http://bing.com')
        time.sleep(randint(4,10))

        for i in range(0,loops):
            if (SF.find_element_by_xpath_validation('//Input[@type="search"]')):
                self.driver.find_element_by_xpath('//Input[@type="search"]').clear()
                time.sleep(2)
                self.driver.find_element_by_xpath('//Input[@type="search"]').send_keys(BingSearchWL.BingStringConcat())
                time.sleep(5)
            if (SF.find_element_by_xpath_validation('//label[@for="sb_form_go"]')):
                self.driver.find_element_by_xpath('//label[@for="sb_form_go"]').click()
            elif (SF.find_element_by_xpath_validation('//Input[@type="submit"]')):
                self.driver.find_element_by_xpath('//Input[@type="submit"]').click()
            else:
                logging.info('Unable to find a porper Submit Button for Search')
            time.sleep(10)

        return True





