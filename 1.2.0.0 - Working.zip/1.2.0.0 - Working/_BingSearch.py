from selenium import webdriver
import time,os,sys,logging,datetime
from random import *
from _BingSearchWordList import *


class BingSearcher:
    driver = None
    
    def Start(driver,loops =  50):
        BingSearcher.driver = driver
        print('Navigating to Bing.com')
        driver.get('http://bing.com')
        time.sleep(randint(4,10))

        for i in range(0,loops):
            if (BingSearcher.find_element_by_xpath_validation('//Input[@type="search"]')):
                driver.find_element_by_xpath('//Input[@type="search"]').clear()
                time.sleep(2)
                driver.find_element_by_xpath('//Input[@type="search"]').send_keys(BingSearchWL.BingStringConcat())
                time.sleep(5)
            if (BingSearcher.find_element_by_xpath_validation('//label[@for="sb_form_go"]')):
                driver.find_element_by_xpath('//label[@for="sb_form_go"]').click()
            elif (BingSearcher.find_element_by_xpath_validation('//Input[@type="submit"]')):
                driver.find_element_by_xpath('//Input[@type="submit"]').click()
            else:
                ErrorHan('Custom Error:\t#8709-124-34523','Custom Error','Unable to find a proper Submit Button for Search')
            time.sleep(10)

        return True

    def find_element_by_xpath_validation(xpath):
            driver = BingSearcher.driver
            try:
                driver.find_element_by_xpath(xpath)
            except Exception as e:
                print('\n\nCould Not Find Xpath:\t' + xpath + '\n\n' + str(e) + '\n\n')
                return False
                    
            return True




