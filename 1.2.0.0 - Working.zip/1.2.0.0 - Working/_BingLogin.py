from selenium import webdriver
import time,os,sys,logging,datetime
from random import *
class BingLogin:
    driver = None
    
    def Logging(error):
        logFile = r'BingLogin_Error.log'
        configFile = open(logFile,"a+")
        errMsg = '\n\n' + str(datetime.datetime.now()) + '\n\n' + str(error)
        print(errMsg)
        configFile.write(errMsg)
        configFile.close()
        
    def Login(driver,username,password):
        BingLogin.driver = driver
        
        print('BingLogin - Step\tNave to login.live.com')
        driver.get('https://login.live.com')
        time.sleep(randint(3,9))
        print('Current Title:\t' + driver.title)
        print('Current URL:\t' + driver.current_url)

        print('\nBingLogin - Step\tFind name("loginfmt")')    
        if (BingLogin.find_element_by_name_validation('loginfmt')):
            driver.find_element_by_name('loginfmt').send_keys(username)
            time.sleep(randint(2,5))
        print('\nBingLogin - Step\tFind xpath(//Input[@type="submit"])')    
        if (BingLogin.find_element_by_xpath_validation('//Input[@type="submit"]')):
            driver.find_element_by_xpath('//Input[@type="submit"]').click()
            time.sleep(randint(5,10))

        print('\nBingLogin - Step\tFind name(\'passwd\')') 
        if (BingLogin.find_element_by_name_validation('passwd')):
            driver.find_element_by_name('passwd').send_keys(password)
            time.sleep(randint(2,5))
        
        print('\nBingLogin - Step\tFind xpath(//Input[@type="submit"])') 
        if (BingLogin.find_element_by_xpath_validation('//Input[@type="submit"]')):
            driver.find_element_by_xpath('//Input[@type="submit"]').click()
            time.sleep(randint(5,10))
        
        print('\nBingLogin - Step\tFind xpath(//Input[@value="No"])') 
        if (BingLogin.find_element_by_xpath_validation('//Input[@value="No"]')):
            driver.find_element_by_xpath('//Input[@value="No"]').click()
            time.sleep(randint(8,15))
        return True
    
    def find_element_by_name_validation(name):
        driver = BingLogin.driver
        try:
            driver.find_element_by_name(name)
        except Exception as e:
            print('\n\nCould Not Find Name:\t' + name + '\n\n' + str(e) + '\n\n')
            return False
                
        return True

    def find_element_by_xpath_validation(xpath):
        driver = BingLogin.driver
        try:
            driver.find_element_by_xpath(xpath)
        except Exception as e:
            print('\n\nCould Not Find Xpath:\t' + xpath + '\n\n' + str(e) + '\n\n')
            return False
                
        return True
        

print('BingLogin\t-\tSUCCESS')
