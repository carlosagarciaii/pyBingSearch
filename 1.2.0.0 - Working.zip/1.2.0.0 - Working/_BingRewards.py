from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time,os,sys,logging,datetime
from random import *

class BingRewards:
    driver = None

    def Logging(error):
        logFile = r'BingLogin_Error.log'
        configFile = open(logFile,"a+")
        errMsg = '\n\n' + str(datetime.datetime.now()) + '\n\n' + str(error)
        print(errMsg)
        configFile.write(errMsg)
        configFile.close()
        
    def Start(driver):
        BingRewards.driver = driver
        
        driver.switch_to.window(driver.window_handles[0])
        
        driver.get('http://bing.com/rewards')
        time.sleep(randint(7,12))
        driver.switch_to.window(driver.window_handles[0])

        print('Finding Daily Links')
        assert BingRewards.RPageLinkCycle('//div[@class="c-card-content"]/card-content/mee-rewards-daily-set-item-content/div/div/a'),'RPageLinkCycle() Failed'

        print('Finding Past Links')

        assert BingRewards.RPageLinkCycle('//mee-rewards-more-activities-card-item/div[@mee-rewardable=""]/div/a[@mee-call-to-action="lightweight"]'),'RPageLinkCycle() Failed'
        return True        
       
    def SafeClick(link):
        try:
            link.click()
        except:
            print('Failed to Click Link')


    def RPageLinkCycle(xpath):
        driver = BingRewards.driver
        links = driver.find_elements_by_xpath(xpath)
        
        for link in links:

            BingRewards.HomeTab()
            try:
                print('Scrolling Link into view')
                driver.execute_script("arguments[0].scrollIntoView();",link)
                time.sleep(3)
                
                print('Clicking Link')
                BingRewards.SafeClick(link)
                time.sleep(5)

                print('Switching to Link Window/Tab')
                driver.switch_to.window(driver.window_handles[1])
                
                if (BingRewards.find_element_by_xpath_validation('//div[contains(text(),"Bing homepage quiz")]') ):
                    print(r'Running:' + '\t' + r'BingQuiz()')
                    BingRewards.BingQuizABC()
                    
                elif (BingRewards.find_element_by_xpath_validation('//div[text()="Today\'s Rewards poll"]')):
                    print(r'Running:' + '\t' + r'DailyPoll()')
                    BingRewards.DailyPoll()

                elif(BingRewards.find_element_by_xpath_validation('//h2[text()="Supersonic quiz"]')  ):
                    print(r'Running:' + '\t' + r'SupersonicQuiz()')
                    BingRewards.SupersonicQuiz()
                elif(BingRewards.find_element_by_xpath_validation('//h2[text()="Lightspeed quiz"]') ):
                    print(r'Running:\t' + r'Lightspeed Quiz')
                    BingRewards.LightspeedQuiz()
                elif(BingRewards.find_element_by_xpath_validation('//h2[@class="b_topTitle"][text()="This or That?"]') ):
                    print(r'Running:\t' + r'This or That')
                    BingRewards.ThisOrThat()

                    
                
                time.sleep(randint(4,8))
                BingRewards.HomeTab()
                print('\n-------------Cycle End-------------\n')
                         
            except Exception as e:
                print('\n\nException Thrown\n\n' + str(e) + '\n\n')
                #BingRewards.Logging(str(e))
                #return False
        return True
    def find_element_by_xpath_safeClick(xpath):
        driver = BingRewards.driver
        try:
            driver.find_element_by_xpath(xpath).click()
            return True
        except:
            print('Could Not Click on:\t' + str(xpath))
            

    def find_element_by_xpath_validation(xpath):
            driver = BingRewards.driver
            try:
                driver.find_element_by_xpath(xpath)
            except Exception as e:
                print('\n\nCould Not Find Xpath:\t' + xpath + '\n\n' + str(e) + '\n\n')
                return False
                    
            return True
        
    def find_element_by_xpath_safeClick(xpath):
        driver = BingRewards.driver
        try:
            element = driver.find_element_by_xpath(xpath)
            driver.execute_script("arguments[0].scrollIntoView();",element)
            element.click()
            time.sleep(3)
        except Exception as e:
            print('Failed to find:\t' + xpath)
            return False
        
            print('Found:\t' + xpath)
        return True
      

    def HomeTab():
        driver = BingRewards.driver
        try:
            driver.switch_to.window(driver.window_handles[1])
            driver.close()
            driver.switch_to.window(driver.window_handles[0])
        except:
            print('Failed to close Tab 1')


    def DailyPoll():
        driver = BingRewards.driver
        driver.switch_to.window(driver.window_handles[1])
        time.sleep(randint(3,6))
        try:
            rng = randint(0,1)
            BingRewards.find_element_by_xpath_safeClick('//div[@id="btoption' + str(rng) + '"]/div/div[@class="bt_PollRadio"]')
        except Exception as e:
            print('\n\nAn Exception Occurred\n\n' + str(e) + '\n\n')
        time.sleep(randint(3,6))
        HomeTab()
        time.sleep(randint(3,6))

    def BingQuizABC():
        driver = BingRewards.driver
        driver.switch_to.window(driver.window_handles[1])
        time.sleep(randint(3,6))
        if (not BingRewards.find_element_by_xpath_validation('//a[text()="Check your dashboard for more ways to earn."]')):
            refreshCounter = 5
            while (1==1):
                refreshCounter -= 1
                rng=randint(1,3)
                if (rng==1):
                    if (BingRewards.find_element_by_xpath_safeClick('//span[@class="wk_Circle"][text()="A"]')):
                        refreshCounter = 5
                    time.sleep(randint(3,6))
                elif(rng==2):
                    if(BingRewards.find_element_by_xpath_safeClick('//span[@class="wk_Circle"][text()="B"]')):
                        refreshCounter = 5
                    time.sleep(randint(3,6))
                else:
                    if(BingRewards.find_element_by_xpath_safeClick('//span[@class="wk_Circle"][text()="C"]')):
                        refreshCounter = 5
                    time.sleep(randint(3,6))
                    

                if (BingRewards.find_element_by_xpath_safeClick('//input[@type="submit"][@value="Next question"]')):
                    refreshCounter = 5
                if (BingRewards.find_element_by_xpath_safeClick('//input[@type="submit"][@value="Get your score"]')):
                    break
                time.sleep(randint(3,6))
                if (refreshCounter == 0):
                    driver.refresh()

        BingRewards.HomeTab()
        time.sleep(randint(3,6))


    def SupersonicQuiz():
        driver = BingRewards.driver
        runQuiz = True
        driver.switch_to.window(driver.window_handles[1])
        time.sleep(randint(3,6))
        #driver.find_element_by_id('rqStartQuiz').click()
        time.sleep(randint(3,6))
        questionNum = int(driver.find_element_by_xpath('//span[@class="rqECredits"]').text.replace(r'"',r'').replace(r' ',r''))/10
        questionNum = int(questionNum)
        try:
            while (runQuiz):
                print('Supersonic Cycle:\t' + str(h))
                for i in range(0,8):
                    if (BingRewards.find_element_by_xpath_validation('//*[contains(text(),"you just earned")]')):
                        print('\n\n------------------Quiz Completed------------------\n\n')
                        runQuiz = False
                        break
                    print('Clicking:\trqAnswerOption' + str(i))
                    BingRewards.find_element_by_xpath_safeClick('//div[@id="rqAnswerOption' + str(i) + '"]')
                    time.sleep(randint(2,4))
                    
        except Exception as e:
            print('\n\nAn Exception has occurred\n\n' + str(e) + '\n\n')
                  
        BingRewards.HomeTab()
        time.sleep(randint(3,6))


    def LightspeedQuiz():
        driver = BingRewards.driver
        driver.switch_to.window(driver.window_handles[1])
        time.sleep(randint(3,6))
        driver.find_element_by_id('rqStartQuiz').click()
        questionNum = int(driver.find_element_by_xpath('//span[@class="rqText"]/span[@class="rqPoints"]').text.replace( r'/',r'').replace(r' ',r'')) /10
        questionNum = int(questionNum)
        try:
            for h in range(0,questionNum):
                print('Supersonic Cycle:\t' + str(h))
                for i in range(0,4):
                    print('Clicking:\trqAnswerOption' + str(i))
                    BingRewards.find_element_by_xpath_safeClick('//input[@id="rqAnswerOption' + str(i) + '"]')
                    time.sleep(randint(3,6))
                    if (driver.find_element_by_xpath('//span[@id="rqAnsStatus"]').text != r'Oops, try again!'):
                        break
                    time.sleep(randint(4,7))
            BingRewards.HomeTab()
        except Exception as e:
            print('\n\nAn Exception has occurred\n\n' + str(e) + '\n\n')
              
        BingRewards.HomeTab()
        time.sleep(randint(3,6))


     
    def ThisOrThat():
        driver = BingRewards.driver
        driver.switch_to.window(driver.window_handles[1])
        time.sleep(randint(3,6))

        try:
            driver.find_element_by_xpath('//input[@type="button"][@value="Start playing"]').click()
            for x in range(0,9):
                time.sleep(randint(4,7))
                print('Getting Option 1')
                option1 = driver.find_element_by_xpath('//div[@id="rqAnswerOption0"]/div[@class="btOptionText"]').text
                print('Getting Option 2')
                option2 = driver.find_element_by_xpath('//div[@id="rqAnswerOption1"]/div[@class="btOptionText"]').text
                print('Getting Question')
                questionText = driver.find_element_by_xpath('//div[@class="bt_queText"]').text.replace(r'?',r'')

                questionText = questionText + r' ' + option1 + r' or ' + option2
                
                links = driver.find_elements_by_xpath('//a')
                links[0].send_keys(Keys.CONTROL + Keys.RETURN)
                time.sleep(randint(3,7))
                driver.switch_to.window(driver.window_handles[2])
                driver.get('http://bing.com')

                time.sleep(randint(3,7))
                print('Searching for:\t' + questionText)
                driver.find_element_by_id("sb_form_q").send_keys(questionText)
                time.sleep(randint(3,5))
                driver.find_element_by_id("sb_form_q").send_keys(Keys.RETURN)
                resultLinks = driver.find_elements_by_xpath('//a')

                for x in range(0,len(resultLinks)):
                    if option1 in resultLinks[x].text or option1.replace(r',',r' ') in resultLinks[x].text :
                        try:
                            while 1==1:
                                driver.switch_to.window(driver.window_handles[2])
                                driver.close()
                        except:
                            print('Search Tabs Closed')
                        driver.switch_to.window(driver.window_handles[1])
                        time.sleep(randint(2,5))
                        driver.find_element_by_xpath('//div[@id="rqAnswerOption0"]').click()
                        break
                    elif option2 in resultLinks[x].text or option2.replace(r',',r' ') in resultLinks[x].text :
                        try:
                            while 1==1:
                                driver.switch_to.window(driver.window_handles[2])
                                driver.close()
                        except:
                            print('Search Tabs Closed')
                        driver.switch_to.window(driver.window_handles[1])
                        time.sleep(randint(2,5))
                        driver.find_element_by_xpath('//div[@id="rqAnswerOption1"]').click()
                        break

                    try:
                        while 1==1:
                            driver.switch_to.window(driver.window_handles[2])
                            driver.close()
                    except:
                        print('Search Tabs Closed')
                        driver.switch_to.window(driver.window_handles[1])
                        driver.refresh()
                        
                        
                time.sleep(randint(3,6))
            
        except Exception as e:
            print('\n\nAN EXCEPTION WAS THROWN\n\n' + str(e) + '\n\n')
        
        BingRewards.HomeTab()
        time.sleep(randint(3,6))             
        
        




                       


print('BingRewards Load:\tSuccess')











    
