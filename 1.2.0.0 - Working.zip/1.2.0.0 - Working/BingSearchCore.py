from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from random import *
import time, logging, os, traceback, sys, datetime, pyautogui, configparser
print('\n\n')

#Logging


loggingDir = os.path.dirname(os.path.abspath(__file__)) + "/Logging/"

if (not os.path.exists(loggingDir)):
    os.mkdir(loggingDir)

logging.basicConfig(filename=loggingDir + os.path.basename(__file__) + '_diagnostic.log', format='%(asctime)s %(message)s', level=logging.DEBUG)
vLoggingSegmenter = "Closing Log\n\n________________________________________________________\n________________________________________________________\n\n"


#Set Config
INIFile = os.path.dirname(os.path.abspath(__file__)) + r'\BingSearch.ini'
config = configparser.ConfigParser()

if (not os.path.exists(INIFile)):
    configFile = open(INIFile,"w+")
    configFile.write(r'')
    configFile.close()
    config.read(INIFile)
    config['BingAuto'] = {'username':'Your_UN','password':'Your_PW'}
    config.write(open(INIFile, 'w'))
    print('Please Edit the Configuration File\n\t' + INIFile)
    sys.exit()
    

config.read(INIFile)
MasterUser = config['BingAuto']['username']
MasterPass = config['BingAuto']['password']



def BrowserKicker(browser):
    if (browser.lower() == "chrome" or browser.lower() == "google"):
        driver = webdriver.Chrome(executable_path='Drivers/chromedriver.exe')
    elif browser.lower() == "edge" :
        driver = webdriver.Edge(executable_path='Drivers/msedgedriver.exe')
    elif (browser.lower() == "ie" or browser.lower() == "explorer" or browser.lower() == "iexplore"):
        driver = webdriver.Ie(executable_path='Drivers/IEDriverServer.exe')
    elif (browser.lower() == "firefox" or browser.lower() == "ff" or browser.lower() == "mozilla"):
        driver = webdriver.Firefox(executable_path='Drivers/geckodriver.exe')
    return driver

#Set Browser
xxBrowser = pyautogui.confirm(text='Select a Browser to Use',title='Browser to Use',buttons=('IE','Edge','FireFox','Chrome','Quit'))
driver = BrowserKicker(xxBrowser)

from _BingLogin import *

BingLogin.Login(driver,MasterUser,MasterPass)


from _BingRewards import *
print('Starting Bing Rewards')
BingRewards.Start(driver)

'''
from _BingSearch import *
print('Starting Bing Search')
BingSearcher.Start(driver)
'''

