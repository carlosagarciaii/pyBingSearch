from random import *
import os,sys,string,time,pyautogui

class Nouns:
    NounList = []   #[r'penguin' , r'shark' , r'dog' , r'cat' , r'snake' , r'gerbil' , r'cheetah' , r'lion' , r'joker' , r'uberman' , r'godzilla' , r'virus' , r'barrel' , r'stove' , r'sandra' , r'playdoh' , r'jail cell' , r'magician' , r'toilet' , r'chips' , r'potato chips' , r'cabinet' , r'cup' , r'vaccum cleaner' , r'house' , r'man' , r'woman' , r'santa clause' , r'thing' , r'monkey' , r'environmentalist' , r'goon' , r'henchman' , r'brick' , r' tower' , r' donkey' , r' elephant' , r' steven crowder' , r'jay london' , r'michael landon' , r'michael jackson' , r'thermometer' , r'thermos',r'Sandra Bullock', r'Steve Buschemi']
    nList = open(r'Lists\NounList.txt')
    for line in nList:
        if (len(line)>3):
            NounList.append(line.replace('\n',''))
    nList.close()
            
    ListLen = len(NounList)
    def rNoun():
        rng = randint(0,Nouns.ListLen - 1)
        return str(Nouns.NounList[rng])

    
class Adj:
    AdjList = []    #["grabthar's" , "sweet","german","irish","dark","legendary","italian","brittish","aussie","stinky", "pink" , "green" , "turquoise" , "old" , "new" , "childish" , "albert's" , "noobish" , "feline" , "ancient" , "repurposed" , "angry" , "hungry" , "flatulent" , "sexy" , "boorish" , "pickled" , "bottled" , "gross" , "free" , "premium" , "destructive" , "bloody" , "comical" , "accessible" , " spanish" , " giant"]
    nList = open(r'Lists\AdjectiveList.txt')
    for line in nList:
        if (len(line)>3):
            AdjList.append(line.replace('\n',''))
    nList.close()
    
    ListLen = len(AdjList)
    def rAdj():
        rng = randint(0,Adj.ListLen - 1)
        return str(Adj.AdjList[rng])

    
class Verbs:
    VerbList = []   #[r'ate pizza with',r'dressed up as an alligator for' ,r'ate twinkies with' ,r'rallied for',r'played the flute with', r'punched' , r'voted for' , r'needed' , r'kneeded' , r'filled' , r'wondered about' , r'published a review about' , r'rotted in a jail cell because of' , r'imitated' , r'trained for' , r'communicated with' , r'fought' , r' heavily petted' , r' proposed a bill to the senate regarding' , r'added another notch to' , r'created a living will for' , r' was out of breath because of' , r' sang a song about' , r'wrote a poem for' , r'made a fur coat inspired by' , r' got served papers for stalking' , r'was scratched by' , r'smoked with' , r'celebrated with' , r'watched tiger king with']
    nList = open(r'Lists\VerbList.txt')
    for line in nList:
        if (len(line)>3):
            VerbList.append(line.replace('\n',''))
    nList.close()
    
    ListLen = len(VerbList)
    def rVerb():
        rng = randint(0,Verbs.ListLen - 1)
        return str(Verbs.VerbList[rng])

class BingURL:
    URL = r'https://www.bing.com/search?q='

class BingSearchWL:
    def BingAutoSearch(bLoops = 50):
        for i in range(0,bLoops):
            
            pyautogui.hotkey(r'ctrl','l')
            time.sleep(1)
            pyautogui.hotkey(r'ctrl','a')
            time.sleep(1)
            pyautogui.write(BingURL.URL  + BingSearch.BingStringConcat() , interval=0.075)
            pyautogui.press(r'enter')
            time.sleep(7)

        print(r'AutoSearch Complete')
        

    def BingStringConcat():
        OutString = Adj.rAdj()
        OutString += ' ' + Nouns.rNoun()
        OutString += ' ' + Verbs.rVerb()
        OutString += ' ' + Adj.rAdj()
        OutString += ' ' + Nouns.rNoun()
        OutString = OutString.replace(r'  ',r' ').replace(r'  ',r' ')
        print(str(OutString))        
        return OutString

print("_BingSearchWordlist Loaded")
